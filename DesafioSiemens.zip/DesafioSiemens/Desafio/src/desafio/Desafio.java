package desafio;

import java.util.Scanner;

public class Desafio {

    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        Factorial fact = new Factorial();
        
        //guarda os valores introduzidos nas variaveis n,n1
        System.out.print("Insira um numero: ");
        int n = in.nextInt();
        System.out.print("Insira um numero: ");
        int n1 = in.nextInt();
        
        //chama a classe com a função
        n = fact.factorialRecursivo(n);
        n1= fact. FactorialIterativo(n1);
        
        //mostra os resultados 
        System.out.print("Resultado Rescursivo: " + n);
        System.out.print("\n\n");
        System.out.print("Resultado Iterativo: "+n1);
        
        
        //#3 Ambos tem vantagens e desvantagens quer a nivel de clareza de codigo
        //   como a nivel de consumo de memória, não penso que algum deles possa
        //   ser mais eficiente que o outro, vai depender mais do programador que
        //   está a escrever o codigo e do metodo que prefere. 
    }
}
