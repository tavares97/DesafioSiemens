package addtodate;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class AddToDate {

    public static void main(String[] args) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        //Obtem do dia
        Calendar cal = Calendar.getInstance();
        //Mostra a data
        System.out.println("Data: "+sdf.format(cal.getTime()));
        
        
        //adiciona os dias
        cal.add(Calendar.DAY_OF_MONTH, 1);
        //guarda nova data em variavel
        String novaData = sdf.format(cal.getTime());
        //mostra nova data
        System.out.println("Nova Data: "+novaData);
    }    
}
