package desafio;

public class Factorial {

    public int factorialRecursivo(int num) {
        if (num == 0) {
            return 1;
        }
        return num * factorialRecursivo(num - 1);
    }

    public int FactorialIterativo(int valor1) {
        int fact = 1;
        
        for (int i = 1; i <= valor1; i++) {
            fact = fact * i;
        }

        return fact;
    }
}
